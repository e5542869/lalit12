﻿namespace AccountsAppWeb.Core.Models
{
    public class UpdateTransactionMasterModel
    {
        public string StringColumn1 { get; set; }
        public string StringColumn2 { get; set; }
        public string StringColumn3 { get; set; }
        public string StringColumn4 { get; set; }
        public string StringColumn5 { get; set; }
    }
}
