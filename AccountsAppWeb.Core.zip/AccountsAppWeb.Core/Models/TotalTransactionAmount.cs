﻿namespace AccountsAppWeb.Core.Models
{
    public class TotalTransactionAmount
    {
        public decimal TotalDebitAmount { get; set; }
        public decimal TotalCreditAmount { get; set; }
    }
}
