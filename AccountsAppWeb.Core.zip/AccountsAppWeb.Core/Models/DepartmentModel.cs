﻿namespace AccountsAppWeb.Core.Models
{
    public class DepartmentModel
    {
        public int Inst_Id { get; set; }
        public string Inst_ShortTitle { get; set; }
        public string Inst_Title { get; set; }
    }
}
