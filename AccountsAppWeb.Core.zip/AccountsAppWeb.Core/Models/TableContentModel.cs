﻿namespace AccountsAppWeb.Core.Models
{
    public class TableContentModel
    {
        public int AccountId { get; set; }
        public string AccountGroupName { get; set; }
        public string PageNumber { get; set; }
    }
}
