﻿namespace AccountsAppWeb.Core.Models
{
    public class ViewPasswordModel
    {
        public string Inst_Title { get; set; }
        public string UA_AccountName { get; set; }
        public string Password { get; set; }
    }
}
