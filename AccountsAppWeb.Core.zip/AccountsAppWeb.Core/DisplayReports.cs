﻿namespace AccountsAppWeb.Core
{
    public class DisplayReports
    {
        //private readonly AccountsAppServiceReference.AccountsAppAPISoapClient accountsAppAPISoapClient;

        //public DisplayReports()
        //{
        //    accountsAppAPISoapClient = new AccountsAppServiceReference.AccountsAppAPISoapClient();

        //}
        //public void FinancialReportsTrialBalanceSheet(string sKey, string instituteId, int financialYearId, int groupId)
        //{
        //    accountsAppAPISoapClient.FinancialReportsTrialBalanceSheet(sKey, instituteId, financialYearId, groupId);
        //}
        //public async void InstDepartmentListAsync(string sKey)
        //{
        //    //await accountsAppAPISoapClient.InstDepartmentListAsync(sKey);
        //}
        //public async void AccountGroupByIdAsync(string sKey, int instituteId)
        //{
        //   // await accountsAppAPISoapClient.AccountGroupByIdAsync(sKey, instituteId);
        //}

       
    }
}
